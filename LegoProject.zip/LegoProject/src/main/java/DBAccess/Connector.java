package DBAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 The purpose of Connector is to...

 @author kasper
 */
public class Connector {
    
    private static final String IP = "165.227.138.161";
    private static final int PORT = 3306;
    private static final String DATABASE = "LegoDB";

    
    private static final String url = "jdbc:mysql://" + IP + ":" + PORT + "/" + DATABASE;
    private static final String username = "anders3";
    private static final String password = "skovlunde3";

    private static Connection singleton;

    public static Connection connection() throws ClassNotFoundException, SQLException  {
        if ( singleton == null ) {
            Class.forName( "com.mysql.jdbc.Driver" );
            singleton = DriverManager.getConnection( url, username, password );
        }
        return singleton;
    }

}
