/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FunctionLayer;

import DBAccess.UserMapper;
import java.util.ArrayList;

/**
 *
 * @author AndersHC
 */
public class Calculator {
    
    
    
    
    public ArrayList<Integer> calculateHouseSpecs(LegoHouse legohouse)throws LegoProjectException{
        
        ArrayList<Integer> specs = new ArrayList<>();
        
        int[] bricksLong = calculateSide(legohouse.length,true);
        int[] bricksShort= calculateSide(legohouse.width,false);
        
        specs.add(bricksLong[0]);
        specs.add(bricksLong[1]);
        specs.add(bricksLong[2]);
        specs.add(bricksShort[0]);
        specs.add(bricksShort[1]);
        specs.add(bricksShort[2]);
        
        
        
        
        
        int[] brickPrice = calculatePrice(bricksLong,bricksShort,legohouse.material,legohouse.heigth);      
               
        specs.add(brickPrice[0]);
        specs.add(brickPrice[1]);
        specs.add(brickPrice[2]);
        specs.add(brickPrice[3]);
              
       
        
        
        
        
      return specs;  
    }
    
    
    
    public int[] calculatePrice(int[] lengthInfo,int[] widthInfo,String material,int heigth) throws LegoProjectException{
        
       int[] prices = new int[4];
        
        int numberOfBig = lengthInfo[0] + widthInfo[0];
        int numberOfMedium = lengthInfo[1] + widthInfo[1];
        int numberOfSmall = lengthInfo[2] + widthInfo[2];
        
        int priceOfBig = (UserMapper.getPrice(3, material))*numberOfBig;
        int priceOfMedium = (UserMapper.getPrice(2, material))*numberOfMedium;
        int priceOfSmall = (UserMapper.getPrice(1, material))*numberOfSmall;
        
        
        
        int totalprice = (priceOfBig+priceOfMedium+priceOfSmall)*heigth;
        
        prices[0]=(numberOfBig);
        prices[1]=(numberOfMedium);
        prices[2]=(numberOfSmall);
        
        
        prices[3]=(totalprice);
     
        
        return prices;
        
        
    }
    
    
    
    
    
    
    public int[] calculateSide(int length,boolean side1){
        
     
       
        int[] sideConstruction = new int[3];
        int numberOfLarge = 0;
        int numberOfMedium = 0;
        int numberOfSmall = 0;
        
        
        if(length%3 == 0){
        
        
        numberOfLarge = sideDivisible3(length);
        numberOfSmall = 2;
        
        
        }else{
            
            numberOfLarge = sideNotDivisible3(length);
                 
            if((numberOfLarge*3)+3 > length){
                numberOfMedium = 1;
                numberOfLarge = numberOfLarge - 1;
                numberOfSmall = 1;
                
               
              }
            
        
        if((numberOfLarge*3)+(numberOfMedium*2)+(numberOfSmall)<length-1){
        numberOfSmall ++;
            
        }
      
      }
        
        if(!side1){
            numberOfSmall --;
        }
   
    sideConstruction[0]=(numberOfLarge)*2;
    sideConstruction[1]=(numberOfMedium)*2;
    sideConstruction[2]=(numberOfSmall)*2;
    
    return sideConstruction;
       
        
        
    
    }
    
    
    
  public int sideDivisible3(int length){
        int amountOfLarge = 0;
        
        
        if(length<=6){
            amountOfLarge = 1;
            return amountOfLarge;
        }
      
        
        amountOfLarge = (length/3)-1;
      
        
        return amountOfLarge;
    }
  //-------------------------------------------------------------------------
  
  
  public int sideNotDivisible3(int length){
      
      int amountOfLarge = 0;
      
      while(amountOfLarge < length){
          
           amountOfLarge = amountOfLarge + 3;
           
           if(amountOfLarge >= length){
               amountOfLarge = amountOfLarge - 3;
               
               amountOfLarge = amountOfLarge/3;
               
               return amountOfLarge;
           }
     
      }
      return 0;
  }
}
