/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FunctionLayer;

import java.util.ArrayList;

/**
 *
 * @author AndersHC
 */
public class LegoHouse {
    int length;
    int width;
    int heigth;
    int totalpieces;
    String material;
    double totalprice;
    

    public LegoHouse(int length,int width,int heigth,String material) {
        this.length = length;
        this.width = width;
        this.heigth = heigth;
        this.totalpieces = totalpieces;
        this.material = material;
        this.totalprice = totalprice;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeigth() {
        return heigth;
    }

    public void setHeigth(int heigth) {
        this.heigth = heigth;
    }

    public int getTotalpieces() {
        return totalpieces;
    }

    public void setTotalpieces(int totalpieces) {
        this.totalpieces = totalpieces;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(double totalprice) {
        this.totalprice = totalprice;
    }
    
    
}
