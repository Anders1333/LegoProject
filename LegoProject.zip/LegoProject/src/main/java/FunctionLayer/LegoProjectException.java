package FunctionLayer;

/**
 * The purpose of LoginSampleException is to...
 * @author kasper
 */
public class LegoProjectException extends Exception {

    public LegoProjectException(String msg) {
        super(msg);
    }
    

}
