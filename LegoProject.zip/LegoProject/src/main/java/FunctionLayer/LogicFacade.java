package FunctionLayer;

import DBAccess.UserMapper;
import java.util.ArrayList;

/**
 * The purpose of LogicFacade is to...
 * @author kasper
 */
public class LogicFacade {

    public static User login( String email, String password ) throws LegoProjectException {
        return UserMapper.login( email, password );
    } 

    public static User createUser( String email, String password ) throws LegoProjectException {
        User user = new User(email, password, "customer");
        UserMapper.createUser( user );
        return user;
    }
    
 
   
    public static ArrayList<Integer> construction(int length,int width,int heigth,String material) throws LegoProjectException{
        Calculator calc = new Calculator(); 
        LegoHouse legohouse = new LegoHouse(length,width,heigth,material);
        ArrayList<Integer> housespecs = calc.calculateHouseSpecs(legohouse);
        return housespecs;
    }
    
    
    

    
    
    
   

}
