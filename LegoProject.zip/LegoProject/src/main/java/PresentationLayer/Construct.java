/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationLayer;

import FunctionLayer.LegoHouse;
import FunctionLayer.LegoProjectException;
import FunctionLayer.LogicFacade;
import FunctionLayer.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author AndersHC
 */
public class Construct extends Command {
        @Override
    String execute( HttpServletRequest request, HttpServletResponse response ) throws LegoProjectException {
    
        int length = Integer.parseInt(request.getParameter("length"));
        int width = Integer.parseInt(request.getParameter("width"));
        int heigth = Integer.parseInt(request.getParameter("heigth"));
        String material = request.getParameter("Material");
        
     
        ArrayList<Integer> specs = LogicFacade.construction(length, width, heigth, material);
          int largeBricks = specs.get(6);
          int mediumBricks = specs.get(7);
          int smallBricks = specs.get(8);
          int totalPrice =  specs.get(9);
          int totalNumber = largeBricks+mediumBricks+smallBricks*heigth;
        HttpSession session = request.getSession();
        
        session.setAttribute("largeBricks", largeBricks);
        session.setAttribute("mediumBricks", mediumBricks);
        session.setAttribute("smallBricks", smallBricks);
        session.setAttribute("totalPrice", totalPrice);
        session.setAttribute("totalNumber",totalNumber);
        session.setAttribute("specs", specs);
        
      return "orderpage";
    }

}

