/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationLayer;

import FunctionLayer.Calculator;
import FunctionLayer.LegoHouse;
import FunctionLayer.LegoProjectException;
import java.util.ArrayList;

/**
 *
 * @author AndersHC
 */
public class TestMain {

    /**
     * @param args the command line arguments
     * @throws FunctionLayer.LegoProjectException
     */
    public static void main(String[] args) throws LegoProjectException{
        
        int length = 6;
        int width = 6;
        int heigth = 2;
        String material = "plastic";
        
        // Should be :  1 0 2 1 0 1 
       
        LegoHouse legohouse = new LegoHouse(length,width,heigth,material);
        
        Calculator calc = new Calculator();
        
        ArrayList<Integer> result = calc.calculateHouseSpecs(legohouse);
        
        for (int i = 0; i < result.size(); i++) {
            System.out.println(result.get(i));
            
        }
  }
}
        
            
   
        
        
    
    

